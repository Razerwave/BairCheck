import { useState } from "react";

type Theme = "dark" | "light";

const THEMES = {
  dark: {
    bg: "#1c1c1e",
    surface: "#2c2c2e",
    surface2: "#3a3a3c",
    border: "#3a3a3c",
    borderHover: "#48484a",
    text: "#f0f0f0",
    textSub: "#8e8e93",
    textMuted: "#636366",
    accent: "#c8ff00",
    accentText: "#3a4a00",
    accentBg: "rgba(200,255,0,0.08)",
    accentBorder: "rgba(200,255,0,0.2)",
    chipBg: "#3a3a3c",
    chipText: "#8e8e93",
    statCard: "#2c2c2e",
    iconBg: "#3a3a3c",
    iconBorder: "#48484a",
    tabBg: "#1c1c1e",
    tabBorder: "#3a3a3c",
    notifBg: "#2c2c2e",
    chevron: "#636366",
    statusBar: "#8e8e93",
    toggleBg: "#2c2c2e",
    toggleBorder: "#48484a",
    shadow: "none",
  },
  light: {
    bg: "#f5f5f3",
    surface: "#ffffff",
    surface2: "#f0f0ee",
    border: "#e8e8e5",
    borderHover: "#d0d0cc",
    text: "#0a0a0a",
    textSub: "#999999",
    textMuted: "#bbbbbb",
    accent: "#2d7a00",
    accentText: "#ffffff",
    accentBg: "rgba(45,122,0,0.08)",
    accentBorder: "rgba(45,122,0,0.2)",
    chipBg: "#f0f0ee",
    chipText: "#888",
    statCard: "#f0f0ee",
    iconBg: "#f5f5f3",
    iconBorder: "#e5e5e2",
    tabBg: "#ffffff",
    tabBorder: "#ebebeb",
    notifBg: "#f0f0ee",
    chevron: "#ccc",
    statusBar: "#aaa",
    toggleBg: "#ffffff",
    toggleBorder: "#e0e0dd",
    shadow: "0 1px 3px rgba(0,0,0,0.06)",
  },
};

const tabs = [
  { id: "home", label: "Нүүр", icon: HomeIcon },
  { id: "inspection", label: "Үзлэг", icon: SearchIcon },
  { id: "add", label: "Нэмэх", icon: PlusIcon },
  { id: "act", label: "Акт", icon: DocIcon },
  { id: "profile", label: "Профайл", icon: UserIcon },
];

export default function App() {
  const [theme, setTheme] = useState<Theme>("dark");
  const t = THEMES[theme];

  return (
    <div style={{ background: theme === "dark" ? "#111113" : "#e8e8e5", minHeight: "100dvh", display: "flex", flexDirection: "column", alignItems: "center", padding: "24px 16px 40px", gap: 24 }}>
      {/* Toggle */}
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: theme === "dark" ? "#555" : "#aaa", fontWeight: 500, letterSpacing: "0.5px", textTransform: "uppercase" }}>Dark</span>
        <button
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          style={{
            width: 52, height: 28, borderRadius: 14,
            background: theme === "dark" ? "#1a1a1a" : "#fff",
            border: `1px solid ${theme === "dark" ? "#333" : "#ddd"}`,
            cursor: "pointer", position: "relative", transition: "all 0.25s",
            boxShadow: "0 1px 4px rgba(0,0,0,0.2)",
          }}
        >
          <div style={{
            position: "absolute", top: 3, left: theme === "dark" ? 3 : 23,
            width: 20, height: 20, borderRadius: 10,
            background: theme === "dark" ? "#c8ff00" : "#2d7a00",
            transition: "left 0.25s cubic-bezier(0.34,1.56,0.64,1)",
            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10,
          }}>
            {theme === "dark" ? "🌙" : "☀️"}
          </div>
        </button>
        <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: theme === "light" ? "#555" : "#444", fontWeight: 500, letterSpacing: "0.5px", textTransform: "uppercase" }}>Light</span>
      </div>

      {/* Side by side on wide, stacked on narrow */}
      <div style={{ display: "flex", gap: 32, flexWrap: "wrap", justifyContent: "center" }}>
        <PhoneFrame theme="dark" />
        <PhoneFrame theme="light" />
      </div>
    </div>
  );
}

function PhoneFrame({ theme }: { theme: Theme }) {
  const t = THEMES[theme];
  const [activeTab, setActiveTab] = useState("home");
  const [showNotif, setShowNotif] = useState(true);

  return (
    <div style={{
      width: 375, borderRadius: 44,
      background: theme === "dark" ? "#111" : "#e0e0dc",
      padding: 10,
      boxShadow: theme === "dark"
        ? "0 40px 80px rgba(0,0,0,0.8), 0 0 0 1px #222"
        : "0 40px 80px rgba(0,0,0,0.15), 0 0 0 1px #ccc",
    }}>
      {/* Screen */}
      <div style={{
        background: t.bg, borderRadius: 36, overflow: "hidden",
        display: "flex", flexDirection: "column",
        minHeight: 720, position: "relative",
        fontFamily: "'Outfit', sans-serif",
      }}>
        {/* Notch */}
        <div style={{ padding: "14px 24px 0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: t.statusBar }}>9:41</span>
          <div style={{ width: 100, height: 28, borderRadius: 14, background: theme === "dark" ? "#000" : "#111", position: "absolute", left: "50%", transform: "translateX(-50%)", top: 8 }} />
          <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
            <svg width="14" height="10" viewBox="0 0 24 12" fill="none">
              <rect x="0.5" y="0.5" width="19" height="11" rx="2.5" stroke={t.statusBar} strokeWidth="1.2" />
              <rect x="2" y="2" width="14" height="8" rx="1.5" fill={t.statusBar} />
              <path d="M21 4v4" stroke={t.statusBar} strokeWidth="1.5" strokeLinecap="round" />
            </svg>
          </div>
        </div>

        {/* Header */}
        <div style={{ padding: "18px 22px 0", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 2 }}>
              <div style={{ width: 7, height: 7, borderRadius: "50%", background: t.accent }} />
              <span style={{ fontWeight: 700, fontSize: 17, color: t.text, letterSpacing: "-0.3px" }}>RentCheck</span>
            </div>
            <span style={{ fontSize: 10, color: t.textSub, letterSpacing: "0.5px", textTransform: "uppercase", fontFamily: "'Inter', sans-serif" }}>Байрны төлөвийг баримтжуулна</span>
          </div>
          <div style={{ width: 38, height: 38, borderRadius: 11, background: t.surface, border: `1px solid ${t.border}`, display: "flex", alignItems: "center", justifyContent: "center", position: "relative", boxShadow: t.shadow }}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
              <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" stroke={t.textSub} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <div style={{ position: "absolute", top: 8, right: 8, width: 7, height: 7, borderRadius: "50%", background: t.accent, border: `2px solid ${t.bg}` }} />
          </div>
        </div>

        {/* Greeting */}
        <div style={{ padding: "22px 22px 0" }}>
          <h1 style={{ fontWeight: 800, fontSize: 32, color: t.text, lineHeight: 1.1, letterSpacing: "-1px", margin: 0 }}>
            Сайн байна уу 👋
          </h1>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: t.textSub, marginTop: 6, lineHeight: 1.5 }}>
            Өнөөдөр байрныхаа мэдээллийг шинэчлээрэй.
          </p>
        </div>

        {/* Offline banner */}
        {showNotif && (
          <div style={{ margin: "16px 22px 0", borderRadius: 13, background: t.notifBg, border: `1px solid ${t.border}`, padding: "12px 14px", display: "flex", gap: 10, alignItems: "flex-start" }}>
            <div style={{ width: 32, height: 32, borderRadius: 9, background: t.surface2, border: `1px solid ${t.border}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M20 17.58A5 5 0 0018 8h-1.26A8 8 0 104 16.25M3 3l18 18" stroke={t.textSub} strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            </div>
            <div style={{ flex: 1 }}>
              <p style={{ fontWeight: 600, fontSize: 12, color: t.text, margin: 0 }}>Офлайн горим</p>
              <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: t.textSub, margin: "2px 0 0", lineHeight: 1.4 }}>Өгөгдөл энэ төхөөрөмжид хадгалагдана.</p>
            </div>
            <button onClick={() => setShowNotif(false)} style={{ background: "none", border: "none", color: t.textMuted, cursor: "pointer", padding: 0, fontSize: 14 }}>✕</button>
          </div>
        )}

        {/* Stats */}
        <div style={{ margin: "16px 22px 0", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          <div style={{ background: t.accent, borderRadius: 13, padding: "14px 16px" }}>
            <p style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: 26, color: theme === "dark" ? "#0a0a0a" : "#fff", margin: 0, lineHeight: 1 }}>1</p>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: theme === "dark" ? t.accentText : "rgba(255,255,255,0.75)", margin: "5px 0 0", fontWeight: 600, letterSpacing: "0.3px" }}>НИЙТ БАЙР</p>
          </div>
          <div style={{ background: t.statCard, border: `1px solid ${t.border}`, borderRadius: 13, padding: "14px 16px", boxShadow: t.shadow }}>
            <p style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: 26, color: t.text, margin: 0, lineHeight: 1 }}>3</p>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: t.textSub, margin: "5px 0 0", fontWeight: 600, letterSpacing: "0.3px" }}>ХҮЛЭЭГДЭЖ БУЙ</p>
          </div>
        </div>

        {/* Properties */}
        <div style={{ padding: "22px 22px 0" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <h2 style={{ fontWeight: 700, fontSize: 17, color: t.text, margin: 0, letterSpacing: "-0.3px" }}>Миний байрнууд</h2>
            <button style={{ background: "none", border: "none", color: t.accent, fontFamily: "'Outfit', sans-serif", fontWeight: 600, fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 3, padding: 0 }}>
              <span style={{ fontSize: 15 }}>+</span> Байр нэмэх
            </button>
          </div>
          <div style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: 14, overflow: "hidden", boxShadow: t.shadow }}>
            <div style={{ padding: "16px 16px 12px", display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 46, height: 46, borderRadius: 12, background: t.iconBg, border: `1px solid ${t.iconBorder}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                  <rect x="3" y="3" width="18" height="18" rx="2" stroke={t.textSub} strokeWidth="1.6" />
                  <path d="M9 21V9h6v12" stroke={t.textSub} strokeWidth="1.6" strokeLinecap="round" />
                  <path d="M3 9h18" stroke={t.textSub} strokeWidth="1.6" />
                  <rect x="7" y="12" width="2" height="2" rx="0.5" fill={t.textSub} />
                  <rect x="15" y="12" width="2" height="2" rx="0.5" fill={t.textSub} />
                </svg>
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontWeight: 700, fontSize: 15, color: t.text, margin: 0, letterSpacing: "-0.2px" }}>Time tower</p>
                <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: t.textSub, margin: "2px 0 0" }}>Assad</p>
              </div>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <path d="M9 18l6-6-6-6" stroke={t.chevron} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div style={{ padding: "0 16px 14px", display: "flex", gap: 6, flexWrap: "wrap" }}>
              {["Хагас тавилгатай", "54 м²"].map(l => (
                <span key={l} style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, fontWeight: 500, color: t.chipText, background: t.chipBg, border: `1px solid ${t.border}`, borderRadius: 5, padding: "2px 7px" }}>{l}</span>
              ))}
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, fontWeight: 500, color: t.accent, background: t.accentBg, border: `1px solid ${t.accentBorder}`, borderRadius: 5, padding: "2px 7px" }}>1 үзлэг</span>
            </div>
          </div>
        </div>

        {/* Quick actions */}
        <div style={{ padding: "22px 22px 0" }}>
          <h2 style={{ fontWeight: 700, fontSize: 17, color: t.text, margin: "0 0 12px", letterSpacing: "-0.3px" }}>Шуурхай үйлдэл</h2>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {[
              { label: "Байр нэмэх", icon: (
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <rect x="3" y="6" width="14" height="15" rx="1.5" stroke={t.accent} strokeWidth="1.7" />
                  <path d="M7 10h6M7 13h4" stroke={t.accent} strokeWidth="1.7" strokeLinecap="round" />
                  <path d="M18 2v6M15 5h6" stroke={t.accent} strokeWidth="1.7" strokeLinecap="round" />
                </svg>
              )},
              { label: "Үзлэг", icon: (
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" stroke={t.accent} strokeWidth="1.7" strokeLinecap="round" />
                  <rect x="9" y="3" width="6" height="4" rx="1" stroke={t.accent} strokeWidth="1.7" />
                  <path d="M9 12l2 2 4-4" stroke={t.accent} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )},
            ].map(({ label, icon }) => (
              <div key={label} style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: 14, padding: "18px 16px", display: "flex", flexDirection: "column", gap: 10, boxShadow: t.shadow }}>
                <div style={{ width: 38, height: 38, borderRadius: 10, background: t.iconBg, border: `1px solid ${t.iconBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>{icon}</div>
                <span style={{ fontWeight: 600, fontSize: 13, color: t.text }}>{label}</span>
              </div>
            ))}
          </div>
        </div>

        <div style={{ flex: 1, minHeight: 20 }} />

        {/* Tab bar */}
        <div style={{ background: t.tabBg, borderTop: `1px solid ${t.tabBorder}`, padding: "8px 4px 20px", display: "flex", justifyContent: "space-around" }}>
          {tabs.map(({ id, label, icon: Icon }) => {
            const isAdd = id === "add";
            const isActive = activeTab === id;
            return (
              <button key={id} onClick={() => setActiveTab(id)} style={{
                background: isAdd ? t.accent : "none", border: "none", cursor: "pointer",
                display: "flex", flexDirection: "column", alignItems: "center", gap: isAdd ? 0 : 3,
                padding: isAdd ? 0 : "4px 10px",
                borderRadius: isAdd ? "50%" : 0, width: isAdd ? 44 : "auto", height: isAdd ? 44 : "auto",
                justifyContent: "center", marginTop: isAdd ? -8 : 0,
                boxShadow: isAdd ? `0 0 16px ${t.accent}55` : "none",
              }}>
                <Icon color={isAdd ? (theme === "dark" ? "#0a0a0a" : "#fff") : isActive ? t.accent : t.textSub} />
                {!isAdd && <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 9, color: isActive ? t.accent : t.textSub, fontWeight: isActive ? 600 : 400 }}>{label}</span>}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ---- Icons ----
function HomeIcon({ color = "#f0f0f0" }) {
  return <svg width="19" height="19" viewBox="0 0 24 24" fill="none"><path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z" stroke={color} strokeWidth="1.8" strokeLinejoin="round" /><path d="M9 21V12h6v9" stroke={color} strokeWidth="1.8" strokeLinecap="round" /></svg>;
}
function SearchIcon({ color = "#444" }) {
  return <svg width="19" height="19" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke={color} strokeWidth="1.8" /><path d="M16.5 16.5L21 21" stroke={color} strokeWidth="1.8" strokeLinecap="round" /></svg>;
}
function PlusIcon({ color = "#0a0a0a" }) {
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke={color} strokeWidth="2.2" strokeLinecap="round" /></svg>;
}
function DocIcon({ color = "#444" }) {
  return <svg width="19" height="19" viewBox="0 0 24 24" fill="none"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" stroke={color} strokeWidth="1.8" strokeLinejoin="round" /><path d="M14 2v6h6M8 13h8M8 17h5" stroke={color} strokeWidth="1.8" strokeLinecap="round" /></svg>;
}
function UserIcon({ color = "#444" }) {
  return <svg width="19" height="19" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="4" stroke={color} strokeWidth="1.8" /><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke={color} strokeWidth="1.8" strokeLinecap="round" /></svg>;
}
